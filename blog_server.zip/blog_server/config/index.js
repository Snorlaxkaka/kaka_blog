// config/index.js
let port

if (process.env.NODE_ENV == 'dev') {
  process.env.DB_USER = 'blog'
  process.env.DB_PASSWORD = 'MonAbC2025DB+=+()'
  process.env.DB_NAME = 'blog'
  process.env.DB_HOST = '127.0.0.1'
  process.env.DB_PORT = 27017
  port = 3000
} else {
  //生产环境
  process.env.DB_USER = 'blog'
  process.env.DB_PASSWORD = 'MonAbC2025DB+=+()'
  process.env.DB_NAME = 'blog'
  process.env.DB_HOST = '127.0.0.1'
  process.env.DB_PORT = 27017
  port = 8250
}

module.exports = {
  dbUser: process.env.DB_USER,
  dbPassword: process.env.DB_PASSWORD,
  dbName: process.env.DB_NAME,
  dbHost: process.env.DB_HOST,
  dbPort: process.env.DB_PORT,
  port
}

