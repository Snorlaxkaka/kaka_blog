// module.exports = (app) => {
//   const mongoose = require("mongoose")
//   //连接的是本地运行的 MongoDB 实例，数据库名称为 blog。
//   mongoose.connect("mongodb://127.0.0.1:27017/blog", {
//     useNewUrlParser: true,
//     useFindAndModify: true,
//     useUnifiedTopology: true,
//     useCreateIndex: true,
//     useFindAndModify: true
//   })
//   require("require-all")(__dirname + "/../models")
// }

const mongoose = require('mongoose')
const config = require('../config/index')

module.exports = (app) => {
  const { dbUser, dbPassword, dbName, dbHost, dbPort } = config
  const dbUri = `mongodb://${dbUser}:${dbPassword}@${dbHost}:${dbPort}/${dbName}`

  mongoose.connect(dbUri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,
    useFindAndModify: false
  }).then(() => {
    console.log("Connected to MongoDB!")
    console.error("Connection string used:", dbUri)
  }).catch((err) => {
    console.error("Error connecting to MongoDB:", err)
    console.error("Connection string used:", dbUri)
  })
  require("require-all")(__dirname + "/../models")
};



